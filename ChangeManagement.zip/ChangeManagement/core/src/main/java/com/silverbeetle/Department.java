package com.silverbeetle;

public class Department {
    private String ID;
}
