package com.silverbeetle;

import java.util.ArrayList;

public class Project {
    private String ID;
    private ArrayList projectTeam = new ArrayList();

    //populate from a table, that gets populated from a front end or file or data feed
    public static void populateProjectTeam (Person person){

    }
}
