package com.silverbeetle;

public class ReleaseChange extends Change {
}
