package com.silverbeetle;

public class Veto {
    private String ID;
}
