package com.silverbeetle;

import java.util.ArrayList;

public class Programme {
    private ArrayList programme = new ArrayList();

    //populate from a table
    public void populateProgramme (Project project){

    }
}
