package com.silverbeetle;

public class Team {
    private String ID;
}
