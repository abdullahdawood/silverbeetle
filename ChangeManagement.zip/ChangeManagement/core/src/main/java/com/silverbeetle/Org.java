package com.silverbeetle;

public class Org {
    private String ID;
}
