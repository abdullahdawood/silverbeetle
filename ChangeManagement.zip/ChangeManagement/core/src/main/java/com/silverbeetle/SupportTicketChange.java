package com.silverbeetle;

public class SupportTicketChange extends Change {
}
